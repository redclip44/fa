from dotenv import load_dotenv
from functools import lru_cache
import os
import pathlib
from fastapi import FastAPI, Form, Request
from fastapi.templating import Jinja2Templates
from .airtable import AirTable

BASE_DIR = pathlib.Path(__file__).parent # src
 

app = FastAPI()
templates = Jinja2Templates(directory=BASE_DIR / "templates")
#http://localhost:/3000/abc # route -> # path
#https://www.somesite.com/abc
  
@app.get("/")
def home_view(request: Request):
    #return {"hello": "world"}
    #return templates.TemplateResponse("home.html", {Request.context})
    return templates.TemplateResponse("home.html", {"request": request})
#load_dotenv()
@lru_cache()
def cached_dotenv():
    #print("AIRTABLE_BASE_ID", os.environ.get("AIRTABLE_BASE_ID"))
    load_dotenv('C:\\Users\\taljaaeb\\Desktop\\fastapi-airtable\\src\.env')
    #print("AIRTABLE_BASE_ID", os.environ.get("AIRTABLE_BASE_ID"))

cached_dotenv()
AIRTABLE_BASE_ID = os.environ.get("AIRTABLE_BASE_ID") 
AIRTABLE_API_KEY = os.environ.get("AIRTABLE_API_KEY")
AIRTABLE_TABLE_NAME = os.environ.get("AIRTABLE_TABLE_NAME")

@app.post("/")
def home_signup_view(request: Request, email:str = Form(...)): 
    """
    TODO add CSRF for security
    """
    # to send email to airtable
    airtable_client = AirTable(
    base_id=AIRTABLE_BASE_ID,
    api_key=AIRTABLE_API_KEY,
    table_name=AIRTABLE_TABLE_NAME,
    )
    #did_send = push_to_airtable(email=email)
    #did_send = AirTable.create_records(email=email)
    did_send = airtable_client.create_records({"email": email})
    return templates.TemplateResponse("home.html", {"request": 
    request, "submitted_email": email, "did_send": did_send})
    