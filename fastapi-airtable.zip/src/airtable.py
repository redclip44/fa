from dataclasses import dataclass
#import os
import requests



@dataclass()
class AirTable:
    base_id:str
    api_key:str
    table_name:str
    
    def create_records(self, data={}):
        if len(data.keys()) == 0:
            return False
        #if email == None:
        endpoint = f"https://api.airtable.com/v0/{self.base_id}/{self.table_name}"
            #endpoint = f"https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{AIRTABLE_TABLE_NAME}"
            #"https://api.airtable.com/v0/appx0nTeR6pmH52Tp/Table%201"
        headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
        }
        data = {
            "records": [
                {
                   "fields": data
                    }
                ]
            }


        r = requests.post(endpoint, json=data, headers=headers)
        print(endpoint, r.json())
        return r.status_code == 200 or r.status_code == 201
"""
curl -v -X POST https://api.airtable.com/v0/appwIiOIgCFBpoZsj/fastapi-to-airtable \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  --data '{
  "records": [
    {
      "fields": {}
    },
    {
      "fields": {}
    }
  ]
}'
"""
           #            data = {
#            "records": [
#                    {
#                    "fields": {
#                        "Email is awesome": email,
#                    }
#                    }
#                ]
#            }
#            """
